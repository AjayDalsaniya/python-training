from django.shortcuts import render
from .models import *
# Create your views here.
def index(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role =="Chairman":
            cid = Chairman.objects.get(user_id = uid)
        
            context = {
                'uid' : uid,
                'cid' : cid,
                
            }
            
            print("---------->image",cid.pic.url)
            return render(request,'index.html',context)
        else:
            sid = SocietyMember.objects.get(user_id = uid)
            print("======>firstname",sid.firstname)
            uid ="Member"
            context = {
                'uid' : uid,
                'sid' : sid,
            }
            
            return render(request,'societymember_index.html',context)           
    else:
        return render(request,'login.html')


def login(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        
        context = {
            'uid' : uid,
            'cid' : cid,
            
        }
        return render(request,'index.html',context)
    else:   
        if  request.POST:
            print("submit button click")
            email = request.POST['email']
            password = request.POST['password']
            
            try :
                uid = User.objects.get(email = email)
                print("=======uid : ",uid)
                if uid.password == password :
                    print("====uid.pass",uid.password)
                    print("====uid.role",uid.role)
                    if uid.role == "Chairman":
                        cid = Chairman.objects.get(user_id=uid)
                        print("====cid",cid)
                        request.session['email'] = email #session creation for login
                        print("------>first name ",cid.firstname)
                        
                        context = {
                            'uid': uid,
                            'cid' : cid,
                        }
                        
                        return render(request,'index.html',context)
                    else:
                        print("Member")
                        sid = SocietyMember.objects.get(user_id = uid)
                        request.session['email'] = email #session creation for login
                        print("------>first name ",sid.firstname)
                        uid ="Member"
                        context = {
                            'uid': uid,
                            'sid' : sid,
                        }
                        
                        return render(request,'societymember_index.html',context)
                else :
                    msg = ("password is invalid")    
                    context = {
                        'msg' : msg,
                    }    
                    return render(request,'login.html',context)
            except Exception as e :
                print("invalid email - user does not exist ",e)
                msg = "invalid email and password "
                context = {
                    'msg' : msg,
                    }
                return render(request,'login.html',context)
    return render(request,'login.html')

def logout(request):
    if "email" in request.session:
        del request.session['email']
        return render(request,'login.html')
    
def profile1(request):
    if "email" in request.session:
            uid = User.objects.get(email=request.session['email'])
            cid = Chairman.objects.get(user_id = uid)
            context = {
                    'uid': uid,
                    'cid' : cid,
            }                    
            return render(request,'profile.html',context)
        
def password_change(request):
    if "email" in request.session:
        if request.POST:
            uid = User.objects.get(email=request.session['email'])
            cid = Chairman.objects.get(user_id = uid)
            
            password = request.POST['password']
            new_password = request.POST['newpassword']
            
            if password == uid.password:
                uid.password = new_password
                cid.pic = request.POST["profilepic"]
                cid.save()
                uid.save() #update  
                print("======save")
                
            context= {
                'uid' : uid,
                'cid' : cid,
            }       
            return render(request,'profile.html',context)

def update_chairman_profile(request):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        
        if uid.role == 'Chairman':
            cid = Chairman.objects.get(user_id = uid)
            if request.POST:
                cid.firstname = request.POST['firstname']
                cid.lastname = request.POST['lastname']
                cid.house_no = request.POST['house_no']
                cid.contact_no = request.POST['contact_no']
                cid.save()
                
                context = {
                    'uid': uid,
                    'cid' : cid,
                } 
                return render(request,'profile.html',context)
            else:
                pass
        else:
            pass
    else:
        return render(request,'login.html')
          
def add_media(request):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        
        if request.POST:
            eid = EventGallery.objects.create(
                user_id = uid,
                media_type = request.POST['mediatype'],
                videofile = request.FILES['pic'],
            )
        
        context = {
                    'uid': uid,
                    'cid' : cid,
                    
                    
                } 
        return render (request,"add_media.html",context) 

def all_member(request):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
          
        sall = SocietyMember.objects.all()
        
        context = {
                'uid': uid,
                'cid' : cid,
                'sall' : sall,
               
        }    
        return render(request,"all_member.html",context)     
    
def add_member(request):
    if "email" in request.session:
        if request.POST:
            uid = User.objects.get(email=request.session['email'])
            mid = Chairman.objects.get(user_id = uid)
            
            context= {
                'uid' : uid,
                'mid' : mid,
            }    
            return render(request,'bankingapp/add_customer.html',context)
            
        else:
            uid = User.objects.get(email = request.session['email'])
            mid = Chairman.objects.get(user_id = uid )
            
            context= {
                'uid' : uid,
                'mid' : mid,
            }   
            return render(request,'bankingapp/add_customer.html',context)        
        
            
                
                
            
          
          
        
        
        
        
    